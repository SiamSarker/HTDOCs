<!DOCTYPE html>

<html>
    <head>
      <title>Buyer Login</title>
    </head>
    <body>
      <h1>Buyer Login</h1>

      <form action="b_login_process.php" method="POST">
        <label for="b_username">Username</label>
        <input type="text" id="b_username" name="b_username">
        <br><br>
        <label for="password">Password</label>
        <input type="password" id="password" name="password">
        <br><br>
        <input type="submit" value="Login">

      </form>
    </body>
</html>

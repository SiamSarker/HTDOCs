<!DOCTYPE html>

<html>
    <head>
      <title>Seller Login</title>
    </head>
    <body>
      <h1>Seller Login</h1>

      <form action="s_login_process.php" method="POST">
        <label for="f_username">Username</label>
        <input type="text" id="f_username" name="f_username">
        <br><br>
        <label for="password">Password</label>
        <input type="password" id="password" name="password">
        <br><br>
        <input type="submit" value="Login">

      </form>
    </body>
</html>
